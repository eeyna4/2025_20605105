#include <iostream>

int main() {
    std::cout << "Hello Planet Earth!" << std::endl;
    return 0;
}
