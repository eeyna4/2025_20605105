#ifndef MATHSLIBADDERH
#define MATHSLIBADDERH
int add(int a, int b);
#endif
