#include "adder.h"

extern "C" MATHS_API int add(int a, int b)
{
    return a + b;
}
